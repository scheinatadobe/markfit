============
Linear Model
============

Liner Model provides an interface to regression functions using the patsy formula specification
language and the pandas data frame library.



